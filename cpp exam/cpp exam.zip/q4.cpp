#include <iostream>
#include <algorithm> // For std::reverse
#include <string>    // For std::string
using namespace std;
int main() 
{
    // Input string
    string str;
    cout << "Enter a string: ";
    getline(cin, str);

    // Reverse the string using std::reverse
    reverse(str.begin(), str.end());

    // Output the reversed string
    cout << "Reversed string: " << str << endl;

    return 0;
}
